package assignment6;
import java.awt.*;
import java.awt.event.*;

public class Assignment6 extends Frame implements KeyListener
{
	TextField keyfld;
	Label lbl1;
	Panel mainPanel;
	public Assignment6()
	{
		
		setSize(500,500);
		setVisible(true);
		setTitle("Key Events");
		setLocationRelativeTo(null);
		setLayout(null);
		addComponents();
		
		this.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				dispose();
			}
		});
		
	}
	public void addComponents()
	{
		Font f = new Font("verdena",Font.BOLD,35);
		
		mainPanel = new Panel();
		mainPanel.setLayout(null);
		mainPanel.setBackground(Color.GRAY);
		mainPanel.setBounds(0,0,500,500);
		add(mainPanel);
		
		lbl1 = new Label("Key Events");
		lbl1.setBounds(20,50,200,25);
		lbl1.setForeground(Color.black);
		lbl1.setFont(new Font("verdena",Font.BOLD,20));
		mainPanel.add(lbl1);
		
		keyfld = new TextField();
		keyfld.setBounds(20,80,460,40);
		keyfld.setBackground(Color.white);
		keyfld.setForeground(Color.black);
		keyfld.setFont(f);
		mainPanel.add(keyfld);
		keyfld.addKeyListener(this);
		
		
	}
    public static void main(String[] args)
    { 
         new Assignment6();
    }
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		System.out.println("Key typed");
		keyfld.setText("Key typed");
	}
	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		System.out.println("Key Pressed");
		keyfld.setText("Key Pressed");
	}
	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		System.out.println("Key Released");
		keyfld.setText("Key Released");
	}
}
