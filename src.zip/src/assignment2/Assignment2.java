package assignment2;
import java.awt.*;

class Myframe extends Frame
{
	 Button b1;
	 Button b2;
	 
	 Myframe() 
	 {
		 setVisible(true); 
		 setSize(500, 500); 
		 setLocation(100,100);
		 setBackground(Color.white);
		 setTitle("Myframe");
		 setLayout(new FlowLayout());
		 
		 b1=new Button("Login");
		 add(b1); 
		// b1.addActionListener(this);
		 b2=new Button("Password");
		 add(b2); 
		 //b2.addActionListener(this);
		 
	 }

}
public class Assignment2 
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub

	}

}
