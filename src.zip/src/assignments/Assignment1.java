package assignments;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
//Frame creation by inheritance method
//extending Frame class to our class Myframe
class Myframe extends Frame
{
	// initializing using constructor  
	Myframe()
	{
		 //creating a button 
		 Button b = new Button("Click Here!!");  
		 // adding button into frame    
		 add(b);
		 // now frame will be visible, by default it is not visible  
		 setVisible(true);
		 // frame size 600 width and 600 height    
		 setSize(600,600);
		 // setting the location of Frame 
		 setLocation(100,50);
		 // setting the title of Frame  
		 setTitle("MyFrame");
		 setResizable(false);
		 
		 this.addWindowListener(new WindowAdapter(){
				public void windowClosing(WindowEvent e)
				{
					dispose();
				}
			});
	}
	
	
}
public class Assignment1 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		// creating instance of Frame class   
		 Myframe obj=new Myframe();
		 

	}

}
