package assignment5;

import java.awt.*;
public class Assignment5 extends Frame{
      
	    private Panel north;
	    private Panel east;
	    private Panel west;
	    private Panel south;
	    private Panel center;
	    
		public static void main(String[] args) 
		{
		
			Assignment5 Aobj= new Assignment5();

		}
		public Assignment5()
		{
			setTitle("Study of Border Layout class");
			setVisible(true);
			setSize(400,500);
			setLocation(100,100);
			setLayout(new BorderLayout());
			
			
			north= new Panel();
			east= new Panel();
			west= new Panel();
			south= new Panel();
			center= new Panel();
			
	        north.setPreferredSize(new Dimension(200,120));
			east.setPreferredSize(new Dimension(150,500));
			west.setPreferredSize(new Dimension(100,500));
			south.setPreferredSize(new Dimension(200,100));
			
			
			north.setBackground(Color.BLUE);
			east.setBackground(Color.GREEN);
			west.setBackground(Color.RED);
			south.setBackground(Color.YELLOW);
			center.setBackground(Color.PINK);
			
			add(north, BorderLayout.NORTH);   // container class add method with component and constraints from border layout class
			add(east, BorderLayout.EAST);
			add(west, BorderLayout.WEST); 
			add(south, BorderLayout.SOUTH);
			add(center, BorderLayout.CENTER);
			
			
	    }
}

