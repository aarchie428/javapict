package assignments1_2;


import java.awt.Button;
import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

//Frame creation by inheritance method

class myframe 
{
	// initializing using constructor  
	myframe()
	{
		 // creating a Frame  
		 Frame f = new Frame();  
		 //creating a button 
		 Button b = new Button("Click Here!!");  
		 // adding button into frame    
		 f.add(b);
		 // now frame will be visible, by default it is not visible  
		 f.setVisible(true);
		 // frame size 600 width and 600 height    
		 f.setSize(600,600);
		 // setting the location of Frame 
		 f.setLocation(100,50);
		 // setting the title of Frame  
		 f.setTitle("MyFrame");
		 f.setResizable(false);
		 
		 f.addWindowListener(new WindowAdapter(){
				public void windowClosing(WindowEvent e)
				{
					f.dispose();
				}
			});
	}
	
	
}
public class Assignment1_2 {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		myframe obj=new myframe();
	}

}
