
import java.awt.Color;
import java.awt.BorderLayout;
import java.awt.Frame;
import java.awt.Dimension;
import java.awt.TextField;
import java.awt.Button;

import java.awt.Panel;




public class study_border_layout extends Frame{
      
	    private Panel north;
	    private Panel east;
	    private Panel west;
	    private Panel south;
	    private Panel center;
	    
		public static void main(String[] args) 
		{
		
			study_border_layout Aobj= new study_border_layout();

		}
		public study_border_layout()
		{
			setTitle("Study of Border Layout class");
			setVisible(true);
			setSize(400,500);
			setLocation(100,100);
			setLayout(new BorderLayout());
			//  option 1
			//*****
			  //setLayout(new BorderLayout(20,20));
			//****
			
			//   option 2
			//*******
			//BorderLayout bl= new BorderLayout();
			//setLayout(bl);
			// Border Layout class contains setHgap and setVgap methods
		//	bl.setHgap(20);
			//bl.setVgap(20);
			//**********
			
			
			
			north= new Panel();
			east= new Panel();
			west= new Panel();
			south= new Panel();
			center= new Panel();
			
	        north.setPreferredSize(new Dimension(200,120));
			east.setPreferredSize(new Dimension(150,500));
			west.setPreferredSize(new Dimension(100,500));
			south.setPreferredSize(new Dimension(200,100));
			
			
			north.setBackground(Color.BLUE);
			east.setBackground(Color.GREEN);
			west.setBackground(Color.RED);
			south.setBackground(Color.YELLOW);
			center.setBackground(Color.PINK);
			
			add(north, BorderLayout.NORTH);   // container class add method with component and constraints from border layout class
			add(east, BorderLayout.EAST);
			add(west, BorderLayout.WEST); 
			add(south, BorderLayout.SOUTH);
			add(center, BorderLayout.CENTER);
			
			//center.add(new Button("Okay"), BorderLayout.CENTER);
			//east.add(new TextField(10), BorderLayout.EAST);
	    }
}
