
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Frame;
import java.awt.Dimension;
import java.awt.Button;
public class study_grid_layout extends Frame{

	 
		public static void main(String[] args) 
		{
		
			study_grid_layout Aobj= new study_grid_layout();

		}
		public study_grid_layout()
		{
			setTitle("Study of Border Layout class");
			setVisible(true);
			setSize(400,500);
			setLocation(100,100);
			
			//setLayout(new GridLayout());
			
			//setLayout(new GridLayout(2,3));  //  row 2 and coloum 3
			//setLayout(new GridLayout(3,2));  //  row 3 and coloum 2
			
			setLayout(new GridLayout(2,3,10,15));  //  row 2, coloum 3, Hgap 10, Vgap 15
			add(new Button("1"));
			add(new Button("2"));
			add(new Button("3"));
			add(new Button("4"));
			add(new Button("5"));
			add(new Button("6"));
	}

}
